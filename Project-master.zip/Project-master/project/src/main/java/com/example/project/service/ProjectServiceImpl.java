package com.example.project.service;

import com.example.project.model.Project;
import com.example.project.repo.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
@Service
public class ProjectServiceImpl implements ProjectService{
    private ProjectRepository projectRepository;
    @Autowired
    public ProjectServiceImpl(ProjectRepository projectRepository) {
        this.projectRepository = projectRepository;
    }

    @Override
    public List<Project> getAllProjectDetails() {
        return projectRepository.findAll();
    }

    @Override
    public Project createProject(Project project) {


        return projectRepository.save(project);
    }

    @Override
    public Project findByProjectId(Integer projectId) {
        Project result=projectRepository.findByProjectId(projectId);
        return result;
    }

    @Override
    @Transactional
    public Integer deleteByProjectId(Integer projectId) {
        return projectRepository.deleteByProjectId(projectId);
    }

    @Override
    public Project updateProject(Project project, Integer id) {
        Project project1=projectRepository.findByProjectId(id);
        project1.setProjectName(project.getProjectName());
        project1.setProjectManagerName(project.getProjectManagerName());
        return projectRepository.save(project1);
    }
}
