package com.example.project.controller;

import com.example.project.model.Project;
import com.example.project.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;

@RestController
public class ProjectController {
    private ProjectService projectService;
    @Autowired
    public ProjectController(ProjectService projectService) {
        this.projectService = projectService;
    }
    @GetMapping(path="/projects")
    public ResponseEntity<Collection<Project>> findAllProject() {

        return ResponseEntity.status(HttpStatus.OK).body(projectService.getAllProjectDetails());
    }
    @GetMapping("/projects/{projectId}")
    public ResponseEntity<Project> findProjectById(@PathVariable("projectId")Integer id)
    {

        return ResponseEntity.status(HttpStatus.OK).body(projectService.findByProjectId(id));
    }
    @PostMapping(path = "/projects")
    public ResponseEntity<Project> createUser(@RequestBody Project project)
    {
        return ResponseEntity.status(HttpStatus.CREATED).body(projectService.createProject(project));
    }
    @DeleteMapping("/projects/del/{projectId}")
    public ResponseEntity<Integer> deleteProjectById(@PathVariable("projectId") Integer projectId) {

        Integer result = projectService.deleteByProjectId(projectId);
        return ResponseEntity.status(HttpStatus.OK).body(result);

    }

    @PutMapping(path = "/projects/up/{id}")
    public ResponseEntity<Project> updateProject(@PathVariable Integer id,@RequestBody Project project)
    {
        Project u=projectService.updateProject(project,id);
        return ResponseEntity.status(HttpStatus.OK).body(u);
    }
}
