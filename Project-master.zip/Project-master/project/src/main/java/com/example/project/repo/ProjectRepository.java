package com.example.project.repo;

import com.example.project.model.Project;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ProjectRepository extends JpaRepository<Project,Integer> {
    @Query
    public Project findByProjectId(Integer projectId);
    @Query
    public Integer deleteByProjectId(Integer projectId);
}
