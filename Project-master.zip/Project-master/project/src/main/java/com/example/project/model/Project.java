package com.example.project.model;

import javax.persistence.*;

@Entity
@Table(name="project")
public class Project {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    @Column(name = "project_id")
    private Integer projectId;
    @Column(name="project_name")
    private String projectName;
    @Column(name="project_manager_name")
    private String projectManagerName;

    public Project() {
    }

    public Project(Integer projectId, String projectName, String projectManagerName) {
        this.projectId = projectId;
        this.projectName = projectName;
        this.projectManagerName = projectManagerName;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getProjectManagerName() {
        return projectManagerName;
    }

    public void setProjectManagerName(String projectManagerName) {
        this.projectManagerName = projectManagerName;
    }
}
