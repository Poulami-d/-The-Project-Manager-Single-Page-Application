package com.example.project.service;

import com.example.project.model.Project;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ProjectService {
    public List<Project> getAllProjectDetails();
    public Project createProject(Project project);
    public Project findByProjectId(Integer projectId);
    public Integer deleteByProjectId(Integer projectId);
    public Project updateProject(Project project, Integer id);
}
