package com.example.demo.service;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.SubTaskNotFoundException;
import com.example.demo.exception.TaskNotFoundException;
import com.example.demo.model.SubTask;
import com.example.demo.model.Task;
import com.example.demo.repo.TaskRepository;

@Service
public class TaskService {
	@Autowired
	private  TaskRepository taskRepository;

	
	/*
	 * public TaskService(TaskRepository taskRepository, SubTaskService
	 * subTaskService) { super(); this.taskRepository = taskRepository;
	 * this.subTaskService = subTaskService; }
	 */
	
	public Task createTask(Task task)
	{
		return taskRepository.save(task);
	}
	
	public List<Task> getAllTasks()
	{
		/*
		 * return StreamSupport .stream(taskRepository.findAll().spliterator(),false)
		 * .collect(Collectors.toList());
		 */
		return taskRepository.findAll();
	}
	public Task getTask(Integer id)
	{
		/*
		 * return taskRepository.findById(id).orElseThrow(() -> new
		 * TaskNotFoundException(id));
		 */
		return taskRepository.findById(id).get();
	}
	public void deleteTask(Integer id)
	{

		taskRepository.deleteById(id);

		return;
	}
	public Task updateTask(Integer id,Task task)
	{
		Task taskToEdit=getTask(id);
		taskToEdit.setOwnerName(task.getOwnerName());
		taskToEdit.setStartDate(task.getStartDate());
		taskToEdit.setEndDate(task.getEndDate());
		return taskRepository.save(taskToEdit);
	}
	/*
	 * public Task addSubTasktoTask(Integer taskId,Integer subTaskId) { Task
	 * task=getTask(taskId); SubTask subTask=subTaskService.getSubTask(subTaskId);
	 * task.addSubtask(subTask); return task; } public Task
	 * removeSubTaskFromTask(Integer taskId,Integer subTaskId) { Task
	 * task=getTask(taskId); SubTask subTask=subTaskService.getSubTask(subTaskId);
	 * task.removeSubtask(subTask); return task; }
	 */

}
