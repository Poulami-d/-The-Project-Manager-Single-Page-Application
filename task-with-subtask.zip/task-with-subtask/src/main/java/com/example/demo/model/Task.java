package com.example.demo.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.example.demo.model.SubTask;

import lombok.Data;
@Data
@Entity
@Table(name = "Task")
public class Task {
	 @Id
	 @GeneratedValue(strategy = GenerationType.AUTO)
	 @Column(name="id")
	 private Integer id;
	 
	 @Column(name="owner_name")
	 private String ownerName;
	 
	 @Column(name="start_date")
	 private String startDate;
	 
	 @Column(name="end_date")
	 private String endDate;
	 
	 @OneToMany(cascade=CascadeType.ALL)
	 @JoinColumn(name="subtask_id")
	 private List<SubTask> subtasks;
	public Task() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Task(String ownerName, String startDate, String endDate, List<SubTask> subtasks) {
		super();
		this.ownerName = ownerName;
		this.startDate = startDate;
		this.endDate = endDate;
		this.subtasks = subtasks;
	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public List<SubTask> getSubtasks() {
		return subtasks;
	}
	public void setSubtasks(List<SubTask> subtasks) {
		this.subtasks = subtasks;
	}
	public void addSubtask(SubTask subtask)
	{
		subtasks.add(subtask);
	}
	 public void removeSubtask(SubTask subtask)
	 {
		 subtasks.remove(subtask);
	 }

}
