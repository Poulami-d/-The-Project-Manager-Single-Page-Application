package com.example.demo.exception;

import java.text.MessageFormat;

public class SubTaskNotFoundException extends RuntimeException{
	
	public SubTaskNotFoundException(Integer id)
	{
		super(MessageFormat.format("Could not found subtask with id: {0} ",id));
	}

}
