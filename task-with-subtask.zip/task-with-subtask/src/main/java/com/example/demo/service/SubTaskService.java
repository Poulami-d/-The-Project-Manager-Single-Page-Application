package com.example.demo.service;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.SubTaskNotFoundException;
import com.example.demo.model.SubTask;
import com.example.demo.repo.SubTaskRepository;

import javax.transaction.Transactional;

@Service
public class SubTaskService {
	
	private SubTaskRepository subTaskRepository;
	
	@Autowired
	public SubTaskService(SubTaskRepository subTaskRepository) {
		super();
		this.subTaskRepository = subTaskRepository;
	}
	
	public SubTask createSubTask(SubTask subTask)
	{
		return subTaskRepository.save(subTask);
	}
	public List<SubTask> getAllSubTasks()
	{
		/*
		 * return StreamSupport .stream(subTaskRepository.findAll().spliterator(),false)
		 * .collect(Collectors.toList());
		 */
		return subTaskRepository.findAll();
	}
	public SubTask getSubTask(Integer id)
	{
		/*
		 * return subTaskRepository.findById(id).orElseThrow(() -> new
		 * SubTaskNotFoundException(id));
		 */
		return subTaskRepository.findById(id).get();
	}
	@Transactional
	public void deleteBySubTaskId(Integer id)
	{
		 subTaskRepository.deleteById(id);
	}
	
	public SubTask updateSubTask(Integer id,SubTask subTask)
	{
		SubTask subTaskToEdit=getSubTask(id);
		subTaskToEdit.setSubtaskTitle(subTask.getSubtaskTitle());
		return subTaskRepository.save(subTaskToEdit);
	}

}
