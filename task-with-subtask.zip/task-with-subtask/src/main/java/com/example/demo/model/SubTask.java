package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity

@Table(name = "Subtask")
public class SubTask {
	 @Id
	 @GeneratedValue(strategy = GenerationType.AUTO)
	 @Column(name="id")
	 private Integer id;
	 
	 @Column(name="subtask_title")
	 private String subtaskTitle;
	 
	public SubTask() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SubTask(String subtaskTitle) {
		super();
		this.subtaskTitle = subtaskTitle;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getSubtaskTitle() {
		return subtaskTitle;
	}
	public void setSubtaskTitle(String subtaskTitle) {
		this.subtaskTitle = subtaskTitle;
	}
	/*
	 * public static SubTask from(SubTaskDto subTaskDto) { SubTask subTask=new
	 * SubTask();
	 * 
	 * subTask.setSubtaskTitle(subTaskDto.getSubtaskTitle()); return subTask; }
	 */
}
