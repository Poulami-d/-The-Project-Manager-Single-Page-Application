package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.SubTask;

import com.example.demo.service.SubTaskService;

@RestController
@RequestMapping("/subtasks")
public class SubTaskController {
	@Autowired
	private SubTaskService subTaskService ;
	
	/*
	 * public SubTaskController(SubTaskService subTaskService) { super();
	 * this.subTaskService = subTaskService; }
	 */
	
	@PostMapping
	/*public ResponseEntity<SubTaskDto> addSubTask(@RequestBody SubTaskDto subTaskDto)
	{
		SubTask subTask=subTaskService.createSubTask(subTask.from(subTaskDto));
		return new ResponseEntity.ok(subTaskService.createSubTask(subTask));
	}*/
	 public SubTask createSubTask(@RequestBody SubTask subtask) {
		  
        return subTaskService.createSubTask(subtask);

    }
	@GetMapping
	public List<SubTask> getAll()
	{
		return subTaskService.getAllSubTasks();
	}
	@GetMapping("/{id}")
	public SubTask getById(@PathVariable Integer id)
	{
		return subTaskService.getSubTask(id);
	}
	@PutMapping("/{id}")
	public SubTask update(@PathVariable Integer id,@RequestBody SubTask subtask)
	{
		return subTaskService.updateSubTask(id,subtask);
	}
	@DeleteMapping("/del/{id}")
	public void deleteSubTask(Integer id)
	
	{
		 subTaskService.deleteBySubTaskId(id);
		 return ;
	}

}
